import { Card, Row, Col, Radio, Input, Button, Steps, Table, message, Form, Select } from 'antd'
import React, { useEffect, useState } from 'react'
import 'antd/dist/antd.css';
import { PoweroffOutlined, UserOutlined, DownOutlined, PlusSquareFilled, PlusCircleFilled } from '@ant-design/icons'
import { Avatar } from 'antd';
import { useNavigate } from 'react-router';
import axios from "axios"

function Admininfo() {
  // const navigate = useNavigate()
  // const handleClickSave = () => {
  //   navigate('/ratinguser')
  // }

  const [Empname, setEmpName] = useState("")
  const [Empcode, setEmpCode] = useState("")
  const [Designation, setDesignation] = useState("")
  const [Dateofjoining, setDateofjoining] = useState("")
  const [Role, setRole] = useState("")
  const [Department, setDepartment] = useState("")
  const [Qualification , setQualification] = useState("")
  const [Grade, setGrade] = useState("")
  const [Experience, setExperience] = useState("")
  const [Skill, setSkill] = useState("")
  const [InterchangeExp, setInterchangeExp] = useState("")
  const [PerformancePeriod, setPerformancePeriod] = useState("")  
  const [Gender, setGender] = useState("")
  const [EmployerType, setEmployerType] = useState("")
  const [Branch, setBranch] = useState("")
  const [Email, setEmail] = useState("")
  const [MobileNumber, setMobileNumber] = useState("")
  const [SpineAccess, setSpineAccess] = useState("")
  const [MediClaim, setMediClaim] = useState("")

  const handleChange = (value) => {
    console.log(`selected ${value}`);
  };

  const navigate = useNavigate()

  const handleClick = (e) =>{
    e.preventDefault()
    let empdetails = axios.post("http://192.168.29.223:3000/user/create",{
      "userId": Empcode,
      "userName":Empname,
      "dateOfJoining": Dateofjoining,
      "gender":Gender,
      "qualifications": Qualification,
      "gradeLevel":Grade,
      "totalExperience": Experience,
      "primarySkill": Skill,
      "interchangeExp": InterchangeExp,
      "performanceAssessmentPeriod": PerformancePeriod,
      "employerType":EmployerType,
      "branch":Branch,
      "department":Department,
      "designation":Designation,
      "email":Email,
      "mobileNumber":MobileNumber,
      "role": Role,
      "spineAccess":SpineAccess,
      "mediClaim":MediClaim,
      }).then((res)=>console.log(res))
      
      // message.success("Employee Informartion Save Successfully")
      // navigate('/admintable')  
  }

  // useEffect(()=>{
  //   axios.post("http://192.168.29.202:3000/fact_employee_detail/create",{
  //   "employeeCode": Empcode,
  //   "employeeName":Empname,
  //   "gender":Gender,
  //   "grade":Grade,
  //   "employerType":EmployerType,
  //   "branch":Branch,
  //   "department":Department,
  //   "designation":Designation,
  //   "email":Email,
  //   "mobile":MobileNumber,
  //   "role":Role,
  //   "spineAccess":SpineAccess,
  //   "mediclaim":MediClaim,
  //   }).then((res)=>console.log(res))
  // })

  return (
    <div className='Employee-Info'>
      <div>
        <Row>
          <Col span={24}>
            <Card className='Card-1'>
              <h2>Employee Assessment Process</h2>
              <h3>Appraisal Form - Personal Information</h3>
              <h3><Button className='Logout-Button'> <PoweroffOutlined /> </Button></h3>
            </Card>
          </Col>
        </Row>
      </div> <br />

      <div>
        <Row>
          <Col lg={8}>
            <Card className='Employee-Card-1'><br />
              <Row>
                <Col lg={7}></Col>
                <Col lg={16}> <Avatar size={70} icon={<UserOutlined />} className="Employee-Info-Avatar" /></Col>
                <Col lg={1}></Col>
              </Row> <br /> <br />
              <Row>
                <Col lg={7}></Col>
                <Col lg={16}> <p className='Employee-Info-Lable'>Employee Name :</p> <span>{'\n'}<Input className='Employee-Info-Input' onChange={(e)=>setEmpName(e.target.value)} required /></span></Col>
                <Col lg={1}></Col>
              </Row><br/>
              <Row>
                <Col lg={7}></Col>
                <Col lg={16}> <p className='Employee-Info-Lable'>Employee Code :</p><span>{'\n'}<Input className='Employee-Info-Input' onChange={(e)=>setEmpCode(e.target.value)} required /></span></Col>
                <Col lg={1}></Col>
              </Row><br />
              <Row>
                <Col lg={7}></Col>
                <Col lg={16}> <p className='Employee-Info-Lable'>Designation :</p><span>{'\n'}<Input className='Employee-Info-Input' onChange={(e)=>setDesignation(e.target.value)} required /></span></Col>
                <Col lg={1}></Col>
              </Row>
            </Card>
          </Col>

          <Col lg={16}>

            <Card className='Employee-Card-2'>
              <Row>
                <Col lg={24}> <p className='Employee-Info-Text'>Employee Information</p> </Col>
              </Row>

              <Row>
                <Col></Col>
                <Col lg={24}>
                  <Card className='Employee-Info-Card'>
                    <Row>
                      <Col lg={1}></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Date Of Joining :</p> <span>{"\n"}<Input className='Employee-Info-Input' type='date' onChange={(e)=>setDateofjoining(e.target.value)} required/></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Role :</p> <span>{"\n"} <Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setRole(value)}
                        required
                        options={[
                          {
                            value: 'developer',
                            label: 'Developer',
                          },
                          {
                            value: 'lucy',
                            label: 'Lucy',
                          },
                        ]}
                      /></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Department :</p> <span>{"\n"}<Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setDepartment(value)}
                        required
                        options={[
                          {
                            value: 'frontend',
                            label: 'Frontend',
                          },
                          {
                            value: 'backend',
                            label: 'Backend',
                          },
                        ]}
                      /></span></Col>
                      <Col lg={5}><p className='Employee-Info-Details'>Qualification :</p> <span>{"\n"}<Input className='Employee-Info-Input' onChange={(e)=>setQualification(e.target.value)} required/></span></Col>
                    </Row> <br />

                    <Row>
                      <Col lg={1}></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Grade/Level :</p> <span>{"\n"}<Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setGrade(value)}
                        required
                        options={[
                          {
                            value: '1',
                            label: '1',
                          },
                          {
                            value: '2',
                            label: '2',
                          },
                          {
                            value: '3',
                            label: '3',
                          },
                        ]} />
                      </span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Total Experience :</p> <span>{"\n"}<Input className='Employee-Info-Input' onChange={(e)=>setExperience(e.target.value)} required/></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Primary Skills :</p> <span>{"\n"}<Input className='Employee-Info-Input' onChange={(e)=>setSkill(e.target.value)} required/></span></Col>
                      <Col lg={5}><p className='Employee-Info-Details'>Interchange Exp :</p> <span>{"\n"}<Input className='Employee-Info-Input' onChange={(e)=>setInterchangeExp(e.target.value)} required/></span></Col>
                    </Row> <br />

                    <Row>
                      <Col lg={1}></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Performance Period:</p> <span>{"\n"}<Input className='Employee-Info-Input' type='date' onChange={(e)=>setPerformancePeriod(e.target.value)} required/></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Gender :</p> <span>{"\n"}<Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setGender(value)}
                        required
                        options={[
                          {
                            value: 'male',
                            label: 'Male',
                          },
                          {
                            value: 'female',
                            label: 'Female',
                          },
                        ]} /></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Employer Type :</p> <span>{"\n"}<Select
                        // defaultValue="Zealeye"
                        className='Employee-Info-Input'
                        onChange={(value)=>setEmployerType(value)}
                        required
                        options={[
                          {
                            value: 'zealeye',
                            label: 'Zealeye',
                          },
                          {
                            value: 'iorta',
                            label: 'Iorta',
                          },
                          {
                            value: 'karsha',
                            label: 'Karsha',
                          },
                        ]}/></span></Col>
                      <Col lg={5}><p className='Employee-Info-Details'>Branch :</p> <span>{"\n"}<Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setBranch(value)}
                        required
                        options={[
                          {
                            value: 'chennai',
                            label: 'Chennai',
                          },
                          {
                            value: 'bangalore',
                            label: 'Bangalore',
                          },
                          {
                            value: 'hyderabad',
                            label: 'Hyderabad',
                          },
                        ]} /></span></Col>
                    </Row> <br />

                    <Row>
                      <Col lg={1}></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Email :</p> <span>{"\n"}<Input className='Employee-Info-Input' type='email' onChange={(e)=>setEmail(e.target.value)} required/></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Mobile Number :</p> <span>{"\n"}<Input className='Employee-Info-Input' onChange={(e)=>setMobileNumber(e.target.value)} required/></span></Col>
                      <Col lg={6}><p className='Employee-Info-Details'>Spine Access :</p> <span>{"\n"}<Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setSpineAccess(value)}
                        required
                        options={[
                          {
                            value: 'yes',
                            label: 'Yes',
                          },
                          {
                            value: 'no',
                            label: 'No',
                          },
                        ]} /></span></Col>
                      <Col lg={5}><p className='Employee-Info-Details'>Medi Claim :</p> <span>{"\n"}<Select
                        className='Employee-Info-Input'
                        onChange={(value)=>setMediClaim(value)}
                        required
                        options={[
                          {
                            value: 'yes',
                            label: 'Yes',
                          },
                          {
                            value: 'no',
                            label: 'No',
                          },
                        ]} /></span></Col>
                    </Row>
                  </Card>
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
      </div> <br />
      <div>
        <Row>
          <Col span={10}></Col>
          <Col span={14}><Button className='Save-and-Next-Button' htmlType='submit' onClick={handleClick}>Save and Next</Button></Col>
        </Row>
      </div> <br />

    </div>
  )
}

export default Admininfo;
